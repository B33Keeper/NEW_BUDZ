<?php
require 'BackEnd_Register.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Budz Badminton</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="registerStyle.css">
    <style>
       
    </style>
</head>
<body>
    <div class="container">
        <!-- Left Side -->
        <div class="left-section">
        <p>Welcome to BudzReserve system! Your gateway to hassle-free court bookings.</p>
            <img src="images/SIGN UP PICTURE 1.png" alt="Signup Illustration"> 
        
            
        </div>

        <!-- Right Side -->
        <div class="right-section">
            <center> 
                 <h2>Create a new account</h2>
                 <p>It's quick and easy.</p>
             </center>
           

            <?php if (isset($successMessage)): ?>
                <div class="alert alert-success"><?= $successMessage ?></div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" action="" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="username" class="form-label">User name</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                    <div class="invalid-feedback">Please enter a username.</div>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                    <div class="invalid-feedback">Please enter a password.</div>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                    <div class="invalid-feedback">Please enter a valid email.</div>
                </div>

                <div class="mb-3">
                    <label for="contact_number" class="form-label">Contact No.</label>
                    <input type="tel" class="form-control" id="contact_number" name="contact_number" required>
                    <div class="invalid-feedback">Please enter your contact number.</div>
                </div>

                <p>
                    By signing up, you agree to abide by Budz Badminton Court’s terms and conditions, 
                    including our booking policies, code of conduct, and privacy guidelines.
                </p>

                <button type="submit" class="btn btn-primary">Sign up</button>
            </form>

            <div class="text-center mt-3">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </div>
    </div>


</body>
</html>
