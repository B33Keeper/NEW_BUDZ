<?php
session_start();
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['court_id']) && isset($_POST['reservation_date'])) {
    $court_id = $_POST['court_id'];
    $reservation_date = $_POST['reservation_date'];

    $sql = "SELECT r.start_time, r.end_time, u.username 
            FROM reservations r 
            JOIN users u ON r.user_id = u.id 
            WHERE r.court_id = ? AND r.reservation_date = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $court_id, $reservation_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $reservations = [];
    while ($row = $result->fetch_assoc()) {
        $reservations[] = $row;
    }
    
    header('Content-Type: application/json');
    echo json_encode($reservations);
}
?> 