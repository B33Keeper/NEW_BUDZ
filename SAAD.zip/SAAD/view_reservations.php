<?php

require 'config.php'; // Database connection
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Fetch reservations made by the user
$user_id = $_SESSION['user_id'];
$userReservationsSql = "SELECT r.id, c.court_name, r.reservation_date, r.start_time, r.end_time FROM reservations r JOIN courts c ON r.court_id = c.id WHERE r.user_id = ? ORDER BY r.reservation_date, r.start_time";
$stmt = $conn->prepare($userReservationsSql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$userReservations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch all reservations for the schedule
$scheduleSql = "SELECT c.court_name, r.reservation_date, r.start_time, r.end_time FROM reservations r JOIN courts c ON r.court_id = c.id ORDER BY r.reservation_date, r.start_time";
$scheduleResult = $conn->query($scheduleSql);
$schedule = $scheduleResult->fetch_all(MYSQLI_ASSOC);

// Handle reservation update or cancellation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update'])) {
        $reservation_id = $_POST['reservation_id'];
        $reservation_date = $_POST['reservation_date'];
        $start_time = $_POST['start_time'];
        $end_time = $_POST['end_time'];

        $updateSql = "UPDATE reservations SET reservation_date = ?, start_time = ?, end_time = ? WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("sssii", $reservation_date, $start_time, $end_time, $reservation_id, $user_id);
        if ($stmt->execute()) {
            $successMessage = "Reservation updated successfully.";

            // Send email notification
            $userEmail = $_SESSION['email'];
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'zhiky090924@gmail.com'; // Your Gmail address
                $mail->Password = 'idcjthkrdgxjekqe';  // Your app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('zhiky090924@gmail.com', 'Budz Badminton');
                $mail->addAddress($userEmail);
                $mail->Subject = 'Reservation Updated';
                $mail->Body = "Dear user,\n\nYour reservation has been updated successfully.\n\nDate: $reservation_date\nTime: $start_time - $end_time.\n\nThank you for choosing Budz Badminton!";

                $mail->send();
                $successMessage .= " Email notification sent.";
            } catch (Exception $e) {
                $successMessage .= " However, email notification failed: " . $mail->ErrorInfo;
            }
        } else {
            $error = "Failed to update reservation.";
        }
    } elseif (isset($_POST['cancel'])) {
        $reservation_id = $_POST['reservation_id'];

        $deleteSql = "DELETE FROM reservations WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($deleteSql);
        $stmt->bind_param("ii", $reservation_id, $user_id);
        if ($stmt->execute()) {
            $successMessage = "Reservation cancelled successfully.";

            // Send email notification
            $userEmail = $_SESSION['email'];
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'zhiky090924@gmail.com'; // Your Gmail address
                $mail->Password = 'idcjthkrdgxjekqe';  // Your app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('zhiky090924@gmail.com', 'Budz Badminton');
                $mail->addAddress($userEmail);
                $mail->Subject = 'Reservation Cancelled';
                $mail->Body = "Dear user,\n\nYour reservation has been cancelled successfully.\n\nThank you for choosing Budz Badminton!";

                $mail->send();
                $successMessage .= " Email notification sent.";
            } catch (Exception $e) {
                $successMessage .= " However, email notification failed: " . $mail->ErrorInfo;
            }
        } else {
            $error = "Failed to cancel reservation.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reservations - Budz Badminton</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar Navigation -->
        <div class="col-md-2 sidebar bg-dark text-white vh-100">
            <div class="text-center mb-4">
                <div class="d-flex align-items-center justify-content-center">
                    <img src="images/BUDZ LOGO.png" alt="Budz Badminton Logo" class="me-2" style="height: 30px;">
                    <h4 class="text-white mb-0">Budz Badminton</h4>
                </div>
            </div>
            <nav class="nav flex-column">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
                <a class="nav-link text-white" href="create_reservation.php">
                    <i class="bi bi-calendar-plus"></i> Create Reservation
                </a>
                <a class="nav-link text-white active" href="view_reservations.php">
                    <i class="bi bi-calendar-check"></i> View Reservations
                </a>
                <a class="nav-link text-white" href="about.php">
                    <i class="bi bi-info-circle"></i> About Us
                </a>
                </a>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <a class="nav-link text-white" href="login.php">
                     <center>Logout</center>
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="col-md-10">
            <div class="container mt-4">
                <h2>View Reservations</h2>

                <?php if (isset($successMessage)): ?>
                    <div class="alert alert-success"> <?= $successMessage ?> </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"> <?= $error ?> </div>
                <?php endif; ?>

                <h4 class="mt-4">Your Reservations</h4>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Court</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($userReservations as $reservation): ?>
                            <tr>
                                <td><?= $reservation['court_name'] ?></td>
                                <td><?= $reservation['reservation_date'] ?></td>
                                <td><?= $reservation['start_time'] ?> - <?= $reservation['end_time'] ?></td>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="reservation_id" value="<?= $reservation['id'] ?>">
                                        <button type="submit" name="cancel" class="btn btn-danger btn-sm">Cancel</button>
                                    </form>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="reservation_id" value="<?= $reservation['id'] ?>">
                                        <input type="date" name="reservation_date" required>
                                        <input type="time" name="start_time" required>
                                        <input type="time" name="end_time" required>
                                        <button type="submit" name="update" class="btn btn-primary btn-sm">Update</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <h4 class="mt-4">All Reservations</h4>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Court</th>
                            <th>Date</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($schedule as $entry): ?>
                            <tr>
                                <td><?= $entry['court_name'] ?></td>
                                <td><?= $entry['reservation_date'] ?></td>
                                <td><?= $entry['start_time'] ?> - <?= $entry['end_time'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
