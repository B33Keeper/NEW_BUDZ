<?php
// dashboard.php
include 'config.php'; // Database connection


$user_id = $_SESSION['user_id'];

// Fetch total reservations for the user
$total_reservations_query = "SELECT COUNT(*) AS total FROM reservations WHERE user_id = ?";
$stmt = $conn->prepare($total_reservations_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_reservations_result = $stmt->get_result()->fetch_assoc();
$total_reservations = $total_reservations_result['total'];

// Fetch the next upcoming reservation
$upcoming_reservation_query = "SELECT reservation_date, start_time FROM reservations 
                              WHERE user_id = ? AND reservation_date >= CURDATE()
                              ORDER BY reservation_date, start_time LIMIT 1";
$stmt = $conn->prepare($upcoming_reservation_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$upcoming_reservation_result = $stmt->get_result()->fetch_assoc();
$next_reservation = $upcoming_reservation_result ? $upcoming_reservation_result : null;

// Fetch announcements
$announcements_query = "SELECT title, content, start_date, end_date FROM announcements 
                        WHERE start_date <= CURDATE() AND end_date >= CURDATE() ORDER BY start_date DESC";
$announcements_result = $conn->query($announcements_query);

// Fetch reservation statistics (last month)
$reservations_last_month_query = "SELECT COUNT(*) AS total FROM reservations 
                                  WHERE user_id = ? AND reservation_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
$stmt = $conn->prepare($reservations_last_month_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$reservations_last_month_result = $stmt->get_result()->fetch_assoc();
$reservations_last_month = $reservations_last_month_result['total'];

// Fetch most frequently reserved court
$most_frequent_court_query = "SELECT courts.court_name, COUNT(reservations.court_id) AS count FROM reservations 
                              JOIN courts ON reservations.court_id = courts.id 
                              WHERE reservations.user_id = ? 
                              GROUP BY reservations.court_id 
                              ORDER BY count DESC LIMIT 1";
$stmt = $conn->prepare($most_frequent_court_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$most_frequent_court_result = $stmt->get_result()->fetch_assoc();
$most_frequent_court = $most_frequent_court_result ? $most_frequent_court_result['court_name'] : "N/A";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">

</head>
<body>
    <div class="container-fluid">
        <div class="row">
         <!-- Sidebar Navigation -->
         <div class="col-md-2 sidebar bg-dark text-white vh-100">
            <div class="text-center mb-4">
                <div class="d-flex align-items-center justify-content-center">
                    <img src="images/BUDZ LOGO.png" alt="Budz Badminton Logo" class="me-2" style="height: 30px;">
                    <h4 class="text-white mb-0">Budz Badminton</h4>
                </div>
            </div>
            <nav class="nav flex-column">
                <a class="nav-link text-white active" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
                <a class="nav-link text-white" href="create_reservation.php">
                    <i class="bi bi-calendar-plus"></i> Create Reservation
                </a>
                <a class="nav-link text-white " href="view_reservations.php">
                    <i class="bi bi-calendar-check"></i> View Reservations
                </a>
                <a class="nav-link text-white" href="about.php">
                    <i class="bi bi-info-circle"></i> About Us
                </a>
                </a>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <a class="nav-link text-white" href="login.php">
                     <center>Logout</center>
                </a>
            </nav>
        </div>

            <main class="col-md-10 ms-sm-auto px-md-4">
                <h2 class="my-4">Dashboard</h2>
                <div class="alert alert-info mb-4">
                    <h4 class="mb-0">Welcome, <?php echo $_SESSION['email']; ?>!</h4>
                </div>

                <!-- Quick Overview Section -->
                 
                <div class="row mb-4 justify-content-center">
                    <div class="col-md-5">
                        <div class="card text-white bg-primary">
                            <div class="card-body">
                                <h5  id="overview">Total Reservations</h5>
                                <p class="card-text">You have made <strong><?php echo $total_reservations; ?></strong> reservations.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="card text-white bg-success">
                            <div class="card-body">
                                <h5  id="overview">Upcoming Reservation</h5>
                                <?php if ($next_reservation): ?>
                                    <p class="card-text">Next reservation on <strong><?php echo $next_reservation['reservation_date']; ?></strong> at <strong><?php echo $next_reservation['start_time']; ?></strong>.</p>
                                <?php else: ?>
                                    <p class="card-text">No upcoming reservations.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Announcements Section -->
                <div class="mb-4">
                    <h3>Announcements</h3>
                    <?php if ($announcements_result->num_rows > 0): ?>
                        <ul class="list-group">
                            <?php while ($announcement = $announcements_result->fetch_assoc()): ?>
                                <li class="list-group-item">
                                    <h5><?php echo $announcement['title']; ?></h5>
                                    <p><?php echo $announcement['content']; ?></p>
                                    <small>Valid from <?php echo $announcement['start_date']; ?> to <?php echo $announcement['end_date']; ?></small>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php else: ?>
                        <p>No announcements at the moment.</p>
                    <?php endif; ?>
                </div>

                <!-- User Statistics Section -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Reservations in the Last Month</h5>
                                <p class="card-text">You made <strong><?php echo $reservations_last_month; ?></strong> reservations in the last month.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Most Frequently Reserved Court</h5>
                                <p class="card-text">Your favorite court is <strong><?php echo $most_frequent_court; ?></strong>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
                        
    
        </div>
    </div>
</body>
</html>
