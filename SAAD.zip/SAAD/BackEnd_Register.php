<?php

require 'config.php'; // Database connection
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $contact_number = $_POST['contact_number'];

    // Check if email already exists
    $checkEmail = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($checkEmail);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error = "Email already exists. Please use a different email.";
    } else {
        // Insert new user into database
        $insertSql = "INSERT INTO users (username, email, password_hash, contact_number) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("ssss", $username, $email, $password, $contact_number);

        if ($stmt->execute()) {
            // Send welcome email using PHPMailer
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'zhiky090924@gmail.com'; // Your Gmail address
                $mail->Password = 'enwozoebljossqqf';  // Your app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('zhiky090924@gmail.com', 'Budz Badminton');
                $mail->addAddress($email, $username);
                $mail->Subject = 'Welcome to Budz Badminton';
                $mail->Body = "Dear $username,\n\n"
                           . "Welcome to Budz Badminton! Your account has been successfully created.\n\n"
                           . "You can now log in and start making reservations for our badminton courts.\n\n"
                           . "Thank you for choosing Budz Badminton!\n\n"
                           . "Best regards,\nBudz Badminton Team";

                $mail->send();
                $successMessage = "Registration successful! Welcome email has been sent. Please proceed to login.";
            } catch (Exception $e) {
                $successMessage = "Registration successful! However, welcome email could not be sent: " . $mail->ErrorInfo;
            }

            header("refresh:3;url=login.php");
        } else {
            $error = "Failed to create reservation. Please try again.";
        }
    }
}


?>