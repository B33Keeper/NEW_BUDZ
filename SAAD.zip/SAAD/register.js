$(document).ready(function () {
    $("#registration-form").on("submit", function (e) {
        e.preventDefault(); // Prevent form submission

        $.ajax({
            url: "", // Keep it the same, it'll submit to the current page
            type: "POST",
            data: $(this).serialize(),
            dataType: "json",
            success: function (response) {
                alert(response.message);  // First alert confirming registration success
                if (response.status === "success") {
                    // After successful registration, show the second alert with a delay
                    setTimeout(function () {
                        alert('Registration successful! You can now close this tab.');
                    }, 1000); // Delay of 1 second before showing the second alert
                } else if (response.status === "error") {
                    alert(response.message); // If there's an error (e.g. email already used)
                }
            },
            error: function () {
                alert("An error occurred. Please try again.");
            },
        });
    });
});




(function () {
    'use strict';
    const forms = document.querySelectorAll('.needs-validation');
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
})();
