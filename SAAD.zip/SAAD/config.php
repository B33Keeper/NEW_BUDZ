<?php
// config.php
session_start();

// Database connection
$host = 'localhost';
$username = 'root';
$password = ''; // Set your database password
$dbname = 'badminton_system';
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
