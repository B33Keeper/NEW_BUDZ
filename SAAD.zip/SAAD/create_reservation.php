<?php

require 'config.php'; // Database connection
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Fetch available courts
$sql = "SELECT * FROM courts WHERE status = 'available'";
$result = mysqli_query($conn, $sql);
$courts = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $court_id = $_POST['court_id'];
    $reservation_date = $_POST['reservation_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // Check if the court is already reserved at the chosen time
    $checkReservationSql = "SELECT * FROM reservations WHERE court_id = ? AND reservation_date = ? AND ((start_time < ? AND end_time > ?) OR (start_time < ? AND end_time > ?))";
    $stmt = $conn->prepare($checkReservationSql);
    $stmt->bind_param("isssss", $court_id, $reservation_date, $end_time, $start_time, $start_time, $end_time);
    $stmt->execute();
    $checkResult = $stmt->get_result();

    if ($checkResult->num_rows > 0) {
        $error = "Sorry, the selected court is already reserved during that time.";
    } else {
        // Insert reservation into the database
        $insertSql = "INSERT INTO reservations (user_id, court_id, reservation_date, start_time, end_time) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("iisss", $user_id, $court_id, $reservation_date, $start_time, $end_time);
        if ($stmt->execute()) {
            $successMessage = "Reservation created successfully!";

            // Send email notification using PHPMailer
            $userEmail = $_SESSION['email'];
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'zhiky090924@gmail.com'; // Your Gmail address
                $mail->Password = 'idcjthkrdgxjekqe';  // Your app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('zhiky090924@gmail.com', 'Budz Badminton');
                $mail->addAddress($userEmail);
                $mail->Subject = 'Reservation Confirmation';
                $mail->Body = "Dear user,\n\nYour reservation has been confirmed.\n\nCourt: $court_id\nDate: $reservation_date\nTime: $start_time - $end_time.\n\nThank you for choosing Budz Badminton!";

                $mail->send();
                $successMessage .= " Email notification has been sent successfully.";
            } catch (Exception $e) {
                $successMessage .= " However, email notification failed: " . $mail->ErrorInfo;
            }
        } else {
            $error = "Failed to create reservation. Please try again.";
        }
    }
}

// Fetch reservations for the selected date (AJAX request handling)
if (isset($_GET['reservation_date'])) {
    $date = $_GET['reservation_date'];
    $reservationsSql = "SELECT court_id, start_time, end_time FROM reservations WHERE reservation_date = ?";
    $stmt = $conn->prepare($reservationsSql);
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result();
    $reservations = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($reservations);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation Page - Budz Badminton</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
<div class="container-fluid">
    <div class="row">
   
    <div class="col-md-2 sidebar bg-dark text-white vh-100">
            <div class="text-center mb-4">
                <div class="d-flex align-items-center justify-content-center">
                    <img src="images/BUDZ LOGO.png" alt="Budz Badminton Logo" class="me-2" style="height: 30px;">
                    <h4 class="text-white mb-0">Budz Badminton</h4>
                </div>
            </div>
            <nav class="nav flex-column">
                <a class="nav-link text-white" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
                <a class="nav-link text-white active" href="create_reservation.php">
                    <i class="bi bi-calendar-plus"></i> Create Reservation
                </a>
                <a class="nav-link text-white" href="view_reservations.php">
                    <i class="bi bi-calendar-check"></i> View Reservations
                </a>
                <a class="nav-link text-white" href="about.php">
                    <i class="bi bi-info-circle"></i> About Us
                </a>
                </a>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <a class="nav-link text-white" href="login.php">
                     <center>Logout</center>
                </a>
            </nav>
        </div>
        <!-- Main Content Area -->
        <div class="col-md-10 main-content">
            <h2 class="mt-4" id="HEADER">Create Reservation</h2>

            <?php if (isset($successMessage)): ?>
                <div class="alert alert-success mt-3"><?= $successMessage ?></div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger mt-3"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label for="court_id" class="form-label">Select Court</label>
                    <select name="court_id" id="court_id" class="form-select" required>
                        <option value="">-- Select Court --</option>
                        <?php foreach ($courts as $court): ?>
                            <option value="<?= $court['id'] ?>"><?= $court['court_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                            
                <div class="mb-3">
                    <label for="reservation_date" class="form-label">Reservation Date</label>
                    <input type="date" class="form-control" id="reservation_date" name="reservation_date" required>
                </div>
                
                            
                <div id="reservations-summary" class="mb-3"></div>

                <div class="mb-3">
                    <label for="start_time" class="form-label">Start Time</label>
                    <input type="time" class="form-control" id="start_time" name="start_time" required>
                </div>

                <div class="mb-3">
                    <label for="end_time" class="form-label">End Time</label>
                    <input type="time" class="form-control" id="end_time" name="end_time" required>
                </div>

                <button type="submit" class="btn btn-primary">Reserve</button>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#reservation_date').on('change', function() {
        const selectedDate = $(this).val();
        if (selectedDate) {
            $.get("?reservation_date=" + selectedDate, function(data) {
                const reservations = JSON.parse(data);
                let summaryHtml = "<h5>Existing Reservations:</h5><ul class='list-group'>";
                reservations.forEach(reservation => {
                    summaryHtml += `<li class='list-group-item'>Court ${reservation.court_id}: ${reservation.start_time} - ${reservation.end_time}</li>`;
                });
                summaryHtml += "</ul>";
                $('#reservations-summary').html(summaryHtml);
            });
        }
    });
});
</script>

</body>
</html
