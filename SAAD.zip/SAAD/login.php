<?php
require 'config.php'; // Include database connection

$error = ''; // Variable to store error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password_hash FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password_hash'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $username;
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "No account found with that username.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Budz Badminton</title>
    <link rel="stylesheet" href="registerStyle.css">
</head>
<body>

<div class="container">
    <div class="left-section">
    <img src="images/LOGIN PICTURE.png" alt="Login Picture">
    </div>

    <div class="right-section">
        <div class="logo">
        <img src="images/BUDZ LOGO.png" alt="BUD'Z LOGO" style="width: 300px; height:80px;">
            <p>BUDZ BADMINTON COURT</p>
        </div>
        
        <div class="login-title">LOGIN</div>
        <p>Welcome back! Please login to your account.</p>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?= $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="username" class="form-label">User name</label>
                <div class="input-group">
                    <span class="icon">&#128100;</span>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <div class="input-group">
                    <span class="icon">&#128274;</span>
                    <input type="password" id="password" name="password" class="form-control" required>
                    <span class="eye-icon" onclick="togglePassword()">👁</span>
                </div>
            </div>

            <button type="submit" name="login" class="btn-submit">Login</button>
        </form>

        <div class="text-links">
            <a href="#">Forgot password</a> <br>
            Don't have an account? <a href="register.php">Sign up</a>
        </div>
    </div>
</div>

<script>
function togglePassword() {
    var passwordField = document.getElementById("password");
    if (passwordField.type === "password") {
        passwordField.type = "text";
    } else {
        passwordField.type = "password";
    }
}
</script>

</body>
</html>
