<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Budz Badminton</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
   
</head>
<body>
    <div class="container-fluid">
        <div class="row">
          <!-- Sidebar Navigation -->
        <style>
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                overflow-y: auto;
                z-index: 100;
            } 
        </style>
        <div class="col-md-2 sidebar bg-dark text-white vh-100">
            <div class="text-center mb-4">
                <div class="d-flex align-items-center justify-content-center">
                    <img src="images/BUDZ LOGO.png" alt="Budz Badminton Logo" class="me-2" style="height: 30px;">
                    <h4 class="text-white mb-0">Budz Badminton</h4>
                </div>
            </div>
            <nav class="nav flex-column">
                <a class="nav-link text-white" href="dashboard.php">
                  Dashboard
                </a>
                <a class="nav-link text-white" href="create_reservation.php">
                   Create Reservation
                </a>
                <a class="nav-link text-white " href="view_reservations.php">
                  View Reservations
                </a>
                <a class="nav-link text-white active" href="about.php">
                     About Us
                </a>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <a class="nav-link text-white" href="login.php">
                     <center>Logout</center>
                </a>
            </nav>
        </div>

            <!-- Main Content Area -->
            <div class="col-md-10 main-content">
                <!-- Hero Section -->
    <div class="hero">
        <h1>About Us</h1>
    </div>

    <!-- Main Content -->
    <div class="container content" style="margin-left: 28%;">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h2>Welcome to Budz Badminton!</h2>
                <p>Budz Badminton is your premier destination for badminton enthusiasts of all skill levels. Whether you're a seasoned player or just starting, our courts are designed to provide you with the best experience possible.</p>

                <h3>Our Mission</h3>
                <p>We aim to promote the sport of badminton by providing top-notch facilities, easy-to-use reservation systems, and a welcoming environment for players of all ages.</p>

                <h3>What We Offer</h3>
                <ul>
                    <li>High-quality badminton courts with proper lighting and flooring.</li>
                    <li>Easy online reservation system to book your preferred time slot.</li>
                    <li>Friendly staff to assist you with your needs.</li>
                    <li>Regular tournaments and events to showcase your skills.</li>
                </ul>

                <h3>Contact Us</h3>
                <p>If you have any questions or need assistance, feel free to reach out to us:</p>
                <ul>
                    <li>Email: support@budzbadminton.com</li>
                    <li>Phone: 09153730100</li>
                    <li>Address: 4th Floor RFC Mall Molino 2 Bacoor Cavite Philippines</li>
                </ul>
                <div class="mapouter"><div class="gmap_canvas"><iframe class="gmap_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=800&amp;height=500&amp;hl=en&amp;q=RFC Mall, Molino, 2nd St, Bacoor, 4102 Cavite, Philippines&amp;t=&amp;z=16&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://embed-googlemap.com">embed-googlemap.com</a></div><style>.mapouter{position:relative;text-align:right;width:800px;height:500px;}.gmap_canvas {overflow:hidden;background:none!important;width:1250px;height:500px;}.gmap_iframe {width:2000px!important;height:500px!important;}</style></div>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <h3>Our Team</h3>
                <p>We are a passionate team of badminton lovers dedicated to providing the best service to our community. From maintaining our courts to organizing events, we strive to make Budz Badminton a place where everyone can enjoy the sport.</p>

                <h3>Join Us</h3>
                <p>Become a part of our growing community. Whether you want to play casually or compete professionally, Budz Badminton is the place to be!</p>
            </div>
        </div>
    </div>

            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
</body>
</html>
